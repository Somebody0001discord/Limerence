[CmdletBinding()]
param(
    [switch]$ForceBuiltin,
    [switch]$NoInstall,
    [switch]$CheckOnly,
    [switch]$RetryInstall
)

# No policy changes, elevation, downloaded bootstrappers, or renamed executables.
$ErrorActionPreference = 'Stop'
$runtimeRoot = Join-Path $PSScriptRoot 'runtime'
$script:ownedNode = $null
$script:builtinStarted = $false
$script:policyDenied = $false
$script:nodeExecutionFailed = $false
$script:stage = 'capabilities'
$script:setupDirectory = $null
$script:logFile = $null
$script:nodeOutput = $null
$script:nodeErrors = $null

function Write-Fact([string]$Message) {
    $line = '[{0}] {1}' -f $script:stage, $Message
    Write-Host $line
    if ($script:logFile) {
        try { Add-Content -LiteralPath $script:logFile -Value ((Get-Date -Format o) + ' ' + $line) -Encoding UTF8 } catch { }
    }
}

function Test-PolicyDenial($Failure) {
    $exception = $Failure.Exception
    while ($exception) {
        if ($exception -is [System.UnauthorizedAccessException]) { return $true }
        if ($exception -is [System.ComponentModel.Win32Exception] -and $exception.NativeErrorCode -in @(5, 577, 1260)) { return $true }
        $exception = $exception.InnerException
    }
    return ([string]$Failure -match '(?i)AppLocker|blocked by.*policy|access (is )?denied|software restriction')
}

function Test-UserAppLocation([string]$File) {
    if (-not $env:LOCALAPPDATA) { return $false }
    try {
        $allowed = [IO.Path]::GetFullPath($env:LOCALAPPDATA).TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
        return [IO.Path]::GetFullPath($File).StartsWith($allowed, [StringComparison]::OrdinalIgnoreCase)
    } catch { return $false }
}

function New-NativeProcess([string]$File, [string]$Arguments) {
    if (-not (Test-UserAppLocation $File)) { throw [UnauthorizedAccessException]::new('Application path is outside the required LOCALAPPDATA directory.') }
    $info = New-Object System.Diagnostics.ProcessStartInfo
    $info.FileName = $File
    $info.Arguments = $Arguments
    $info.UseShellExecute = $false
    $info.CreateNoWindow = $true
    $info.WorkingDirectory = $runtimeRoot
    $info.RedirectStandardOutput = $true
    $info.RedirectStandardError = $true
    $process = New-Object System.Diagnostics.Process
    $process.StartInfo = $info
    [void]$process.Start()
    return $process
}

function Stop-OwnedNode {
    if ($script:ownedNode) {
        try { if (-not $script:ownedNode.HasExited) { $script:ownedNode.Kill(); [void]$script:ownedNode.WaitForExit(2000) } } catch { }
        $script:ownedNode.Dispose()
        $script:ownedNode = $null
    }
}

function Find-CompatibleNode {
    $script:stage = 'node-version'
    $command = Get-Command node -CommandType Application -All -ErrorAction SilentlyContinue | Where-Object { Test-UserAppLocation $_.Source } | Select-Object -First 1
    if (-not $command) { Write-Fact 'No Node on PATH is inside current-user LOCALAPPDATA; other locations will not be executed.'; return $null }
    $process = $null
    try {
        $process = New-NativeProcess $command.Source '--version'
        $outputTask = $process.StandardOutput.ReadToEndAsync()
        $errorTask = $process.StandardError.ReadToEndAsync()
        if (-not $process.WaitForExit(4000)) { $process.Kill(); $script:nodeExecutionFailed = $true; Write-Fact 'Node version check exceeded 4 seconds.'; return $null }
        $output = $outputTask.GetAwaiter().GetResult().Trim()
        $errors = $errorTask.GetAwaiter().GetResult().Trim()
        if ($process.ExitCode -eq 0 -and $output -match '^v(\d+)\.') {
            if ([int]$Matches[1] -ge 20) { Write-Fact ('Existing Node ' + $output + ' is a candidate; actual relay checks follow.'); return $command.Source }
            Write-Fact ('Node ' + $output + ' is below the launcher candidate floor of major version 20.')
        } else {
            $script:nodeExecutionFailed = $true
            if (($output + ' ' + $errors) -match '(?i)AppLocker|blocked|access (is )?denied|policy') { $script:policyDenied = $true }
            Write-Fact ('Node version check failed (exit ' + $process.ExitCode + ').')
        }
    } catch {
        if (Test-PolicyDenial $_) { $script:policyDenied = $true }
        $script:nodeExecutionFailed = $true
        Write-Fact ('Node could not run: ' + $_.Exception.Message)
    } finally { if ($process) { $process.Dispose() } }
    return $null
}

function Try-InstallNode {
    $script:stage = 'node-install'
    if ($NoInstall) { Write-Fact 'Installation disabled by -NoInstall.'; return $false }
    if ($script:nodeExecutionFailed) { Write-Fact 'Existing Node could not run; no replacement installation will be attempted. Trying only the permitted built-in alternative.'; return $false }
    if ($script:policyDenied) { Write-Fact 'Execution policy/access denial detected; no replacement runtime will be installed.'; return $false }
    if (-not $script:setupDirectory) { Write-Fact 'Cannot persist an attempt marker; automatic installation skipped.'; return $false }
    $marker = Join-Path $script:setupDirectory 'node-install-attempt.json'
    if ((Test-Path -LiteralPath $marker) -and -not $RetryInstall) { Write-Fact 'A previous installation attempt is recorded. Use -RetryInstall for an explicit new attempt.'; return $false }
    # Record before invoking a package manager. Missing winget also counts as the single attempt.
    $markerStream = $null
    try {
        $mode = [System.IO.FileMode]::CreateNew
        if ($RetryInstall) { $mode = [System.IO.FileMode]::Create }
        $markerStream = [System.IO.File]::Open($marker, $mode, [System.IO.FileAccess]::Write, [System.IO.FileShare]::None)
        $record = @{ attemptedAt = (Get-Date -Format o); status = 'attempt-recorded' } | ConvertTo-Json
        $bytes = [Text.Encoding]::UTF8.GetBytes($record)
        $markerStream.Write($bytes, 0, $bytes.Length)
    } catch { Write-Fact 'Cannot write a new installation attempt marker; automatic installation skipped.'; return $false }
    finally { if ($markerStream) { $markerStream.Dispose() } }
    $manager = Get-Command winget -CommandType Application -All -ErrorAction SilentlyContinue | Where-Object { Test-UserAppLocation $_.Source } | Select-Object -First 1
    if (-not $manager -or -not (Test-UserAppLocation $manager.Source)) {
        try { @{ attemptedAt = (Get-Date -Format o); status = 'cannot-install-winget-missing' } | ConvertTo-Json | Set-Content -LiteralPath $marker -Encoding UTF8 } catch { }
        Write-Fact 'No permitted user-local winget is available; automatic installation cannot run.'
        return $false
    }
    $process = $null
    $status = 'failed'
    try {
        Write-Fact 'Attempting the normal winget Node LTS installation for the current user (45 second limit).'
        $process = New-NativeProcess $manager.Source ('install --exact --id OpenJS.NodeJS.LTS --scope user --location "' + (Join-Path $env:LOCALAPPDATA 'Programs\Limerence\Node') + '" --silent --accept-package-agreements --accept-source-agreements --disable-interactivity')
        $outTask = $process.StandardOutput.ReadToEndAsync()
        $errTask = $process.StandardError.ReadToEndAsync()
        if (-not $process.WaitForExit(45000)) { $process.Kill(); $status = 'timed-out'; Write-Fact 'winget exceeded 45 seconds; stopped the winget process started here.'; return $false }
        $installText = $outTask.GetAwaiter().GetResult() + $errTask.GetAwaiter().GetResult()
        if ($installText -match '(?i)AppLocker|blocked by.*policy|access (is )?denied|software restriction') { $script:policyDenied = $true; $status = 'policy-denied' }
        elseif ($process.ExitCode -eq 0) { $status = 'completed'; Write-Fact 'winget completed; checking Node on the normal PATH again.'; return $true }
        Write-Fact ('winget did not complete successfully (exit ' + $process.ExitCode + ').')
    } catch {
        if (Test-PolicyDenial $_) { $script:policyDenied = $true; $status = 'policy-denied' }
        Write-Fact ('winget could not run: ' + $_.Exception.Message)
    } finally {
        if ($process) { $process.Dispose() }
        try { @{ attemptedAt = (Get-Date -Format o); status = $status } | ConvertTo-Json | Set-Content -LiteralPath $marker -Encoding UTF8 } catch { }
    }
    return $false
}

function Assert-FreePorts {
    $listeners = @()
    try {
        foreach ($port in @(43159, 43160, 43161)) {
            $listener = New-Object System.Net.Sockets.TcpListener -ArgumentList ([System.Net.IPAddress]::Loopback), $port
            $listeners += $listener
            $listener.Start()
        }
    } finally { foreach ($listener in $listeners) { $listener.Stop() } }
}

function Read-LocalHttp([string]$Path, [int]$TimeoutMilliseconds = 5000) {
    $request = [System.Net.HttpWebRequest]::Create('http://127.0.0.1:43159/' + $Path)
    $request.Proxy = $null
    $request.Timeout = $TimeoutMilliseconds
    $request.ReadWriteTimeout = $TimeoutMilliseconds
    $response = $null
    $reader = $null
    try {
        $response = $request.GetResponse()
        if ([int]$response.StatusCode -ne 200) { throw 'Expected HTTP 200.' }
        $reader = New-Object System.IO.StreamReader($response.GetResponseStream())
        return $reader.ReadToEnd()
    } finally { if ($reader) { $reader.Dispose() }; if ($response) { $response.Dispose() } }
}

function Send-WispPacket($Socket, [byte[]]$Bytes, $Token) {
    $segment = [System.ArraySegment[byte]]::new($Bytes)
    [void]$Socket.SendAsync($segment, [System.Net.WebSockets.WebSocketMessageType]::Binary, $true, $Token).GetAwaiter().GetResult()
}

function Receive-WispPacket($Socket, $Token) {
    $buffer = New-Object byte[] 65536
    $message = New-Object System.IO.MemoryStream
    try {
        do {
            $received = $Socket.ReceiveAsync([System.ArraySegment[byte]]::new($buffer), $Token).GetAwaiter().GetResult()
            if ($received.MessageType -ne [System.Net.WebSockets.WebSocketMessageType]::Binary) { throw 'Expected a binary Wisp message.' }
            $message.Write($buffer, 0, $received.Count)
            if ($message.Length -gt 262144) { throw 'Wisp probe response exceeded its size limit.' }
        } until ($received.EndOfMessage)
        return ,$message.ToArray()
    } finally { $message.Dispose() }
}

function Test-WispRoundTrip {
    $script:stage = 'wisp-data-probe'
    $socket = New-Object System.Net.WebSockets.ClientWebSocket
    $cancellation = New-Object System.Threading.CancellationTokenSource
    $cancellation.CancelAfter(8000)
    try {
        $socket.Options.SetRequestHeader('Origin', 'http://127.0.0.1:43159')
        [void]$socket.ConnectAsync([Uri]'ws://127.0.0.1:43160/wisp/', $cancellation.Token).GetAwaiter().GetResult()
        $greeting = Receive-WispPacket $socket $cancellation.Token
        if ($greeting.Length -lt 5 -or $greeting[0] -notin @(3, 5) -or [BitConverter]::ToUInt32($greeting, 1) -ne 0) { throw 'Invalid Wisp greeting.' }
        if ($greeting[0] -eq 5) { Send-WispPacket $socket ([byte[]]@(5, 0, 0, 0, 0, 2, 0)) $cancellation.Token }
        $hostname = [Text.Encoding]::ASCII.GetBytes('127.0.0.1')
        $connect = [byte[]](@(1, 1, 0, 0, 0, 1) + [BitConverter]::GetBytes([uint16]43161) + $hostname)
        Send-WispPacket $socket $connect $cancellation.Token
        $request = [Text.Encoding]::ASCII.GetBytes("GET /echo HTTP/1.1`r`nHost: 127.0.0.1:43161`r`nConnection: close`r`n`r`n")
        Send-WispPacket $socket ([byte[]](@(2, 1, 0, 0, 0) + $request)) $cancellation.Token
        $text = ''
        while (-not $cancellation.IsCancellationRequested) {
            $packet = Receive-WispPacket $socket $cancellation.Token
            if ($packet.Length -lt 5) { throw 'Truncated Wisp packet.' }
            $streamId = [BitConverter]::ToUInt32($packet, 1)
            if ($packet[0] -eq 2 -and $streamId -eq 1 -and $packet.Length -gt 5) {
                $text += [Text.Encoding]::ASCII.GetString($packet, 5, $packet.Length - 5)
                if ($text -match '^HTTP/1\.[01] 200(?: |\r\n)' -and $text.Contains("`r`n`r`n")) { return }
            }
            if ($packet[0] -eq 4 -and $streamId -eq 1) { throw 'Wisp stream closed before an HTTP 200 DATA response.' }
        }
        throw 'Wisp DATA round trip timed out.'
    } finally { $socket.Abort(); $socket.Dispose(); $cancellation.Dispose() }
}

function Test-Backend {
    $script:stage = 'http-probe'
    $status = Read-LocalHttp 'helper-status.json' | ConvertFrom-Json
    if ($status.service -ne 'limerence-local-helper' -or $status.relay -ne 'ws://127.0.0.1:43160/wisp/' -or $status.relayOwned -ne $true) { throw 'Unexpected helper status.' }
    $page = Read-LocalHttp 'Limerence-Localhost.html'
    if ($page -notmatch '(?i)<!doctype|<html') { throw 'The localhost page was not served as HTML.' }
    Test-WispRoundTrip
}

try {
    # Persist facts when the normal per-user directory is writable. Failure never triggers an install.
    if ($env:LOCALAPPDATA) {
        try {
            $directory = Join-Path $env:LOCALAPPDATA 'Limerence\setup'
            [void](New-Item -ItemType Directory -Path $directory -Force)
            $script:logFile = Join-Path $directory 'launcher.log'
            Add-Content -LiteralPath $script:logFile -Value '' -Encoding UTF8
            $script:setupDirectory = $directory
        } catch { $script:logFile = $null }
    }
    Write-Fact ('LanguageMode=' + $ExecutionContext.SessionState.LanguageMode + '; PowerShell=' + $PSVersionTable.PSVersion + '; .NET=' + [Environment]::Version)
    $listenerSupported = [System.Net.HttpListener]::IsSupported
    $webSocketType = [System.Net.WebSockets.WebSocket]
    $hasCreateFromStream = @($webSocketType.GetMethods() | Where-Object { $_.Name -eq 'CreateFromStream' }).Count -gt 0
    Write-Fact ('HttpListener.IsSupported=' + $listenerSupported + '; WebSocket.CreateFromStream=' + $hasCreateFromStream)
    $capabilitySocket = New-Object System.Net.WebSockets.ClientWebSocket
    $capabilitySocket.Dispose()
    Write-Fact 'ClientWebSocket construction succeeded; actual network permission will be checked.'

    $nodePath = $null
    if (-not $ForceBuiltin) {
        $nodePath = Find-CompatibleNode
        if (-not $nodePath -and (Try-InstallNode)) {
            # Refresh only normal user/machine PATH entries; do not search or rename alternate binaries.
            $env:PATH = [Environment]::GetEnvironmentVariable('Path', 'Machine') + ';' + [Environment]::GetEnvironmentVariable('Path', 'User')
            $nodePath = Find-CompatibleNode
        }
    }
    $selected = $null
    if ($nodePath) {
        $script:stage = 'node-start'
        try {
            Assert-FreePorts
            $serverPath = Join-Path $runtimeRoot 'relay\server.mjs'
            $script:ownedNode = New-NativeProcess $nodePath ('"' + $serverPath + '" --with-helper')
            $script:nodeOutput = $script:ownedNode.StandardOutput.ReadToEndAsync()
            $script:nodeErrors = $script:ownedNode.StandardError.ReadToEndAsync()
            $ready = $false
            $deadline = [DateTime]::UtcNow.AddSeconds(8)
            while ([DateTime]::UtcNow -lt $deadline -and -not $script:ownedNode.HasExited) {
                try { [void](Read-LocalHttp 'helper-status.json' 500); $ready = $true; break } catch { Start-Sleep -Milliseconds 100 }
            }
            if (-not $ready) { throw 'Node helper did not become ready within 8 seconds.' }
            Test-Backend
            if ($script:ownedNode.HasExited) { throw 'Node helper exited during its checks.' }
            $selected = 'existing Node'
        } catch {
            if (Test-PolicyDenial $_) { $script:policyDenied = $true }
            Write-Fact ('Node backend failed: ' + $_.Exception.Message)
            Stop-OwnedNode
        }
    }
    if (-not $selected) {
        $script:stage = 'builtin-start'
        if ($ExecutionContext.SessionState.LanguageMode -ne 'FullLanguage') { throw 'Built-in server requires FullLanguage and allowed Add-Type.' }
        Assert-FreePorts
        $source = Join-Path $runtimeRoot 'powershell\LimerenceServer.cs'
        if (-not ('LimerenceBuiltin.Server' -as [type])) { Add-Type -Path $source }
        $script:builtinStarted = $true
        [LimerenceBuiltin.Server]::Start($runtimeRoot)
        Test-Backend
        $selected = 'built-in .NET'
    }
    $script:stage = 'ready'
    Write-Fact ('Backend: ' + $selected + '.')
    Write-Fact 'Hosting/WebSocket/Wisp checks passed; browser compatibility still requires testing.'
    Write-Host 'Open http://127.0.0.1:43159/Limerence-Localhost.html'
    if (-not $CheckOnly) {
        Write-Host 'Keep this window open. Ctrl+C stops the servers started here.'
        while ($true) {
            Start-Sleep -Milliseconds 500
            if ($script:ownedNode -and $script:ownedNode.HasExited) { throw 'The Node helper stopped.' }
        }
    }
} catch {
    Write-Fact ('Unavailable: ' + $_.Exception.Message)
    exit 1
} finally {
    Stop-OwnedNode
    if ($script:builtinStarted) { try { [LimerenceBuiltin.Server]::Stop() } catch { } }
}
