// Optional Limerence relay. Only reviewed game hosts and the owned fixture are allowed.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { server as wisp, logging } from '@mercuryworkshop/wisp-js/server';
import { NodeTCPSocket, lookup_ip } from './node_modules/@mercuryworkshop/wisp-js/src/server/net.mjs';
import { WebSocketServer } from 'ws';
import ipaddr from 'ipaddr.js';
const metrics={connections:0,activeConnections:0,streams:0,sent:0,received:0,requests:[],headers:[],destinations:{}};
const approvedHosts=new Set(['turbowarp.org','trampoline.turbowarp.org','windchimes.turbowarp.org','clouddata.turbowarp.org','projects.scratch.mit.edu','assets.scratch.mit.edu','api.scratch.mit.edu','itch.io','static.itch.io','html-classic.itch.zone',
 // Primary open-source project hosts verified by the Beta2 research owner.
 'gabrielecirulli.github.io','hextris.github.io','adarkroom.doublespeakgames.com']);
// The launcher gates initial website navigation to catalog hosts. Public HTTPS
// subresources and publisher redirects must be allowed for real browser pages.
// Loopback/private network access is denied except our exact owned fixture.
Object.assign(wisp.options,{hostname_whitelist:null,port_whitelist:[443,43161],allow_private_ips:false,allow_loopback_ips:true,allow_udp_streams:false,stream_limit_total:100});
function initialHosts(){
 const hosts=new Set(approvedHosts);
 try{const manifest=JSON.parse(fs.readFileSync(fileURLToPath(new URL('../navigation-hosts.json',import.meta.url)),'utf8'));for(const host of manifest.hosts||[])if(typeof host==='string'&&/^[a-z0-9.-]+$/i.test(host))hosts.add(host);}catch{}
 const sourceRoot=fileURLToPath(new URL('../../',import.meta.url));
 const candidates=[path.join(sourceRoot,'src','catalog.json'),...['a','b','c'].map(batch=>path.join(sourceRoot,'research','batch-'+batch+'.json'))];
 for(const file of candidates){try{const data=JSON.parse(fs.readFileSync(file,'utf8').replace(/^\uFEFF/,''));for(const game of (Array.isArray(data)?data:data.games||[])){const value=game.embedUrl||game.launchUrl||game.sourceUrl;if(value){const url=new URL(value);if(url.protocol==='https:')hosts.add(url.hostname);}}}catch{}}
 return [...hosts];
}
logging.set_level(logging.WARN);
class CountedSocket extends NodeTCPSocket {
 constructor(host,port){if(!((host==='127.0.0.1'&&port===43161)||port===443))throw new Error('Only public HTTPS destinations and the owned test target are supported.');super(host,port);this.requestedHostname=host;metrics.streams++;}
 async connect(){
  const owned=this.requestedHostname==='127.0.0.1'&&this.port===43161;
  const ip=await lookup_ip(this.requestedHostname);
  if(!owned&&(!ipaddr.isValid(ip)||ipaddr.process(ip).range()!=='unicast'))throw new Error('Private, loopback, reserved and non-public network destinations are not allowed.');
  // Pin the address actually checked; do not resolve the hostname again when
  // opening the socket (which would allow a DNS change between check/connect).
  this.hostname=ip;metrics.destinations[this.requestedHostname]=(metrics.destinations[this.requestedHostname]||0)+1;
  return super.connect();
 }
 async send(data){metrics.sent+=data.byteLength;return super.send(data);}
 async recv(){const data=await super.recv();if(data)metrics.received+=data.byteLength;return data;}
}
const relay=http.createServer((req,res)=>{res.setHeader('Content-Type','application/json');res.setHeader('Access-Control-Allow-Origin','http://127.0.0.1:43159');res.end(JSON.stringify(metrics));});
relay.on('upgrade',(req,socket,head)=>{
 if(req.url!=='/wisp/'||!['http://127.0.0.1:43159','null'].includes(req.headers.origin)){socket.destroy();return;}
 metrics.connections++;metrics.activeConnections++;socket.once('close',()=>metrics.activeConnections--);
 wisp.routeRequest(req,socket,head,{TCPSocket:CountedSocket});
});
function respondTarget(req,res){
 metrics.requests.push(req.url);metrics.headers.push(req.headers);
 res.setHeader('Content-Type',req.url.startsWith('/echo')?'application/json':'text/html');
 if(req.url.startsWith('/echo'))res.end(JSON.stringify(req.headers));
 else if(req.url.startsWith('/game'))res.end(fs.readFileSync(fileURLToPath(new URL('../test-game.html',import.meta.url))));
 else {res.statusCode=404;res.end('Unknown controlled target');}
}
const target=http.createServer(respondTarget);
const echoSockets=new WebSocketServer({noServer:true});
target.on('upgrade',(req,socket,head)=>{
 if(req.headers.upgrade==='h2c'){
  // This owned HTTP/1 fixture declines libcurl's optional HTTP/2 upgrade with
  // a normal response; destroying the socket here caused libcurl error52.
  const response=new http.ServerResponse(req);response.assignSocket(socket);response.shouldKeepAlive=false;respondTarget(req,response);return;
 }
 if(req.url!=='/socket'){socket.destroy();return;}
 metrics.headers.push(req.headers);echoSockets.handleUpgrade(req,socket,head,ws=>{ws.send(JSON.stringify(req.headers));ws.on('message',data=>ws.send(data));});
});
relay.listen(43160,'127.0.0.1',()=>console.log('Limerence local Wisp: public HTTPS443 and owned test target43161; private destinations denied.'));
target.listen(43161,'127.0.0.1');
let helper;
if(process.argv.includes('--with-helper')){
 const root=path.resolve(fileURLToPath(new URL('..',import.meta.url)));
 helper=http.createServer((req,res)=>{
  if(req.url==='/helper-status.json'){
   res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'});
   res.end(JSON.stringify({service:'limerence-local-helper',version:2,relay:'ws://127.0.0.1:43160/wisp/',relayOwned:true,approvedHosts:initialHosts(),publicHttpsResources:true}));return;
  }
  let relative;try{relative=decodeURIComponent(new URL(req.url,'http://localhost').pathname);}catch{res.writeHead(400);res.end();return;}
  const file=path.resolve(root,'.'+relative);
  if(!file.startsWith(root+path.sep)||!fs.existsSync(file)||!fs.statSync(file).isFile()){res.writeHead(404);res.end('File unavailable');return;}
  const mime={'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.wasm':'application/wasm','.json':'application/json','.css':'text/css'};
  res.writeHead(200,{'Content-Type':mime[path.extname(file)]||'application/octet-stream','Cache-Control':'no-store','Service-Worker-Allowed':'/'});fs.createReadStream(file).pipe(res);
 });
 helper.listen(43159,'127.0.0.1',()=>console.log('Limerence local external helper http://127.0.0.1:43159/player.html — Ctrl+C stops it.'));
}
const stop=()=>{relay.close();target.close();helper?.close();process.exit();};process.on('SIGINT',stop);process.on('SIGTERM',stop);
