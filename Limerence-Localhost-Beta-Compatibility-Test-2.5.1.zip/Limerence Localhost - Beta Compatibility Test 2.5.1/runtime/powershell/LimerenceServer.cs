// Built-in, loopback-only helper. Compile in memory using PowerShell Add-Type.
using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Net.WebSockets;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Security.Cryptography;
using System.Threading;
using System.Threading.Tasks;

namespace LimerenceBuiltin {
 public static class Server {
  const int MaxMessage = 2 * 1024 * 1024;
  static string root;
  static TcpListener[] listeners;
  static CancellationTokenSource lifetime;
  static readonly ConcurrentDictionary<TcpClient, byte> clients = new ConcurrentDictionary<TcpClient, byte>();
  static long sent, received, totalStreams, connections, active;
  public static long MetricsActive { get { return Interlocked.Read(ref active); } }
  public static long MetricsSent { get { return Interlocked.Read(ref sent); } }
  public static long MetricsReceived { get { return Interlocked.Read(ref received); } }
  public static string MetricsJson { get { return "{\"connections\":" + Interlocked.Read(ref connections) + ",\"activeConnections\":" + MetricsActive + ",\"streams\":" + Interlocked.Read(ref totalStreams) + ",\"sent\":" + MetricsSent + ",\"received\":" + MetricsReceived + "}"; } }
  public static void Start(string runtimeRoot) {
   if (listeners != null) throw new InvalidOperationException("The built-in helper is already running.");
   // Construct the preferred platform transport or managed fallback before binding.
   using (WebSocket probe = CreateWebSocket(new MemoryStream(), null)) { }
   root = Path.GetFullPath(runtimeRoot).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
   if (!File.Exists(Path.Combine(root, "player.html"))) throw new DirectoryNotFoundException("The runtime folder must contain player.html.");
   lifetime = new CancellationTokenSource();
   sent = received = totalStreams = connections = active = 0;
   TcpListener[] pending = new TcpListener[3];
   try {
    for (int i = 0; i < 3; i++) { pending[i] = new TcpListener(IPAddress.Loopback, 43159 + i); pending[i].Server.ExclusiveAddressUse = true; pending[i].Start(32); }
    listeners = pending;
    CancellationToken stop = lifetime.Token;
    for (int i = 0; i < 3; i++) { int port = 43159 + i; TcpListener listener = pending[i]; Run(delegate { return Accept(listener, port, stop); }); }
   } catch { foreach (TcpListener listener in pending) if (listener != null) listener.Stop(); lifetime.Dispose(); lifetime = null; throw; }
  }
  public static void Stop() {
   if (listeners == null) return;
   lifetime.Cancel();
   foreach (TcpListener listener in listeners) listener.Stop();
   foreach (TcpClient client in clients.Keys) client.Close();
   listeners = null;
  }
  static void Run(Func<Task> work) { Task.Run(async delegate { try { await work().ConfigureAwait(false); } catch { /* Each socket is disposed by its owner. */ } }); }
  static async Task Accept(TcpListener listener, int port, CancellationToken stop) {
   while (!stop.IsCancellationRequested) {
    TcpClient client;
    try { client = await listener.AcceptTcpClientAsync().ConfigureAwait(false); } catch { break; }
    if (clients.Count >= 128) { client.Close(); continue; }
    clients.TryAdd(client, 0);
    Run(delegate { return Serve(client, port, stop); });
   }
  }
  sealed class Request {
   public string Method, Target;
   public Dictionary<string,string> Headers = new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase);
   public string HeadersJson() { List<string> values = new List<string>(); foreach (KeyValuePair<string,string> pair in Headers) values.Add(Json(pair.Key.ToLowerInvariant()) + ":" + Json(pair.Value)); return "{" + String.Join(",", values.ToArray()) + "}"; }
  }
  static async Task<Request> ReadRequest(NetworkStream stream, CancellationToken stop) {
   using (CancellationTokenSource timeout = CancellationTokenSource.CreateLinkedTokenSource(stop)) {
    timeout.CancelAfter(15000);
    MemoryStream bytes = new MemoryStream(); byte[] one = new byte[1]; int tail = 0;
    while (bytes.Length < 32768) {
     int n;
     using (timeout.Token.Register(delegate { stream.Dispose(); })) n = await stream.ReadAsync(one, 0, 1, timeout.Token).ConfigureAwait(false);
     if (n == 0) throw new IOException("Incomplete request.");
     bytes.WriteByte(one[0]); tail = (tail << 8) | one[0];
     if (tail == 0x0d0a0d0a) break;
    }
    if (tail != 0x0d0a0d0a) throw new IOException("Headers too large.");
    string[] lines = Encoding.ASCII.GetString(bytes.ToArray()).Split(new string[] { "\r\n" }, StringSplitOptions.None);
    string[] first = lines[0].Split(' ');
    if (first.Length != 3 || !first[2].StartsWith("HTTP/1.")) throw new IOException("Invalid HTTP request.");
    Request request = new Request(); request.Method = first[0]; request.Target = first[1];
    for (int i = 1; i < lines.Length && lines[i] != ""; i++) {
     int colon = lines[i].IndexOf(':'); if (colon < 1) throw new IOException("Invalid header.");
     string key = lines[i].Substring(0, colon).Trim(), value = lines[i].Substring(colon + 1).Trim();
     if (request.Headers.ContainsKey(key)) throw new IOException("Duplicate header."); request.Headers.Add(key, value);
    }
    return request;
   }
  }
  static string Header(Request r, string name) { string value; return r.Headers.TryGetValue(name, out value) ? value : ""; }
  static async Task Serve(TcpClient client, int port, CancellationToken stop) {
   try {
    client.NoDelay = true; NetworkStream stream = client.GetStream(); Request r = await ReadRequest(stream, stop).ConfigureAwait(false);
    if (Header(r, "Host") != "127.0.0.1:" + port) { await Reply(stream, 403, "text/plain", Encoding.UTF8.GetBytes("Loopback host required"), false, stop).ConfigureAwait(false); return; }
    string path = r.Target.Split('?')[0];
    if (r.Method != "GET" && r.Method != "HEAD") { await Reply(stream, 405, "text/plain", new byte[0], false, stop).ConfigureAwait(false); return; }
    bool upgrade = String.Equals(Header(r, "Upgrade"), "websocket", StringComparison.OrdinalIgnoreCase);
    if (port == 43160 && upgrade) {
     string origin = Header(r, "Origin");
     if (path != "/wisp/" || (origin != "null" && origin != "http://127.0.0.1:43159")) { await Reply(stream, 403, "text/plain", new byte[0], false, stop).ConfigureAwait(false); return; }
     using (WebSocket ws = await Upgrade(stream, r, stop).ConfigureAwait(false)) {
      Interlocked.Increment(ref connections); Interlocked.Increment(ref active);
      try { await new Relay(ws, stop, Header(r, "Sec-WebSocket-Protocol") != "").Run().ConfigureAwait(false); } finally { Interlocked.Decrement(ref active); }
     }
     return;
    }
    if (port == 43161 && upgrade && path == "/socket") {
     using (WebSocket ws = await Upgrade(stream, r, stop).ConfigureAwait(false)) {
      await SendWs(ws, Encoding.UTF8.GetBytes(r.HeadersJson()), WebSocketMessageType.Text, stop).ConfigureAwait(false);
      while (ws.State == WebSocketState.Open) { Message msg = await ReceiveWs(ws, stop).ConfigureAwait(false); if (msg == null) break; await SendWs(ws, msg.Bytes, msg.Type, stop).ConfigureAwait(false); }
     }
     return;
    }
    if (upgrade) { await Reply(stream, 404, "text/plain", new byte[0], false, stop).ConfigureAwait(false); return; }
    if (port == 43160) { await Reply(stream, 200, "application/json", Encoding.UTF8.GetBytes(MetricsJson), r.Method == "HEAD", stop).ConfigureAwait(false); return; }
    if (port == 43161) {
     if (path == "/echo") await Reply(stream, 200, "application/json", Encoding.UTF8.GetBytes(r.HeadersJson()), r.Method == "HEAD", stop).ConfigureAwait(false);
     else if (path == "/game") await StaticFile(stream, "test-game.html", r.Method == "HEAD", stop).ConfigureAwait(false);
     else await Reply(stream, 404, "text/plain", new byte[0], false, stop).ConfigureAwait(false);
     return;
    }
    if (path == "/helper-status.json") { await Reply(stream, 200, "application/json", Encoding.UTF8.GetBytes(StatusJson()), r.Method == "HEAD", stop).ConfigureAwait(false); return; }
    string relative = null;
    try { relative = Uri.UnescapeDataString(path); } catch { }
    if (relative == null) { await Reply(stream, 400, "text/plain", new byte[0], false, stop).ConfigureAwait(false); return; }
    if (!relative.StartsWith("/") || relative.IndexOf('\\') >= 0 || relative.IndexOf(':') >= 0 || relative.IndexOf('\0') >= 0) { await Reply(stream, 400, "text/plain", new byte[0], false, stop).ConfigureAwait(false); return; }
    if (relative == "/") relative = "/player.html";
    await StaticFile(stream, relative.Substring(1), r.Method == "HEAD", stop).ConfigureAwait(false);
   } catch { } finally { byte ignored; clients.TryRemove(client, out ignored); client.Close(); }
  }
  static async Task StaticFile(NetworkStream stream, string relative, bool head, CancellationToken stop) {
   string file = Path.GetFullPath(Path.Combine(root, relative.Replace('/', Path.DirectorySeparatorChar)));
   bool safe = file.StartsWith(root + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase);
   if (safe) {
    string current = file;
    while (current != root && current != null) { if ((File.Exists(current) || Directory.Exists(current)) && (File.GetAttributes(current) & FileAttributes.ReparsePoint) != 0) { safe = false; break; } current = Path.GetDirectoryName(current); }
   }
   if (!safe || !File.Exists(file)) { await Reply(stream, 404, "text/plain", Encoding.UTF8.GetBytes("File unavailable"), head, stop).ConfigureAwait(false); return; }
   string ext = Path.GetExtension(file).ToLowerInvariant();
   string mime = ext == ".html" ? "text/html; charset=utf-8" : ext == ".js" || ext == ".mjs" ? "text/javascript" : ext == ".wasm" ? "application/wasm" : ext == ".json" ? "application/json" : ext == ".css" ? "text/css" : ext == ".png" ? "image/png" : ext == ".svg" ? "image/svg+xml" : ext == ".ico" ? "image/x-icon" : "application/octet-stream";
   using (FileStream source = File.OpenRead(file)) {
    await ResponseHeaders(stream, 200, mime, source.Length, stop).ConfigureAwait(false);
    if (!head) { byte[] buffer = new byte[65536]; int n; while ((n = await source.ReadAsync(buffer, 0, buffer.Length, stop).ConfigureAwait(false)) > 0) await Write(stream, buffer, 0, n, stop).ConfigureAwait(false); }
   }
  }
  static async Task Reply(NetworkStream stream, int status, string mime, byte[] body, bool head, CancellationToken stop) { await ResponseHeaders(stream, status, mime, body.Length, stop).ConfigureAwait(false); if (!head) await Write(stream, body, 0, body.Length, stop).ConfigureAwait(false); }
  static Task ResponseHeaders(NetworkStream stream, int status, string mime, long length, CancellationToken stop) {
   string reason = status == 200 ? "OK" : status == 403 ? "Forbidden" : status == 404 ? "Not Found" : status == 405 ? "Method Not Allowed" : "Bad Request";
   byte[] bytes = Encoding.ASCII.GetBytes("HTTP/1.1 " + status + " " + reason + "\r\nContent-Type: " + mime + "\r\nContent-Length: " + length + "\r\nConnection: close\r\nCache-Control: no-store\r\nService-Worker-Allowed: /\r\nAccess-Control-Allow-Origin: http://127.0.0.1:43159\r\nX-Content-Type-Options: nosniff\r\n\r\n");
   return Write(stream, bytes, 0, bytes.Length, stop);
  }
  static async Task Write(Stream stream, byte[] bytes, int offset, int count, CancellationToken stop) { using (CancellationTokenSource timeout = CancellationTokenSource.CreateLinkedTokenSource(stop)) { timeout.CancelAfter(60000); using (timeout.Token.Register(delegate { stream.Dispose(); })) await stream.WriteAsync(bytes, offset, count, timeout.Token).ConfigureAwait(false); } }
  static async Task<WebSocket> Upgrade(NetworkStream stream, Request r, CancellationToken stop) {
   byte[] key;
   try { key = Convert.FromBase64String(Header(r, "Sec-WebSocket-Key")); } catch { throw new IOException("Invalid WebSocket key."); }
   if (key.Length != 16 || Header(r, "Sec-WebSocket-Version") != "13" || Header(r, "Connection").ToLowerInvariant().IndexOf("upgrade") < 0 || r.Method != "GET") throw new IOException("Invalid WebSocket upgrade.");
   string accept;
   using (SHA1 sha = SHA1.Create()) accept = Convert.ToBase64String(sha.ComputeHash(Encoding.ASCII.GetBytes(Header(r, "Sec-WebSocket-Key") + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11")));
   string protocol = null;
   if (Header(r, "Sec-WebSocket-Protocol") != "") {
    protocol = Header(r, "Sec-WebSocket-Protocol").Split(',')[0].Trim();
    if (!Regex.IsMatch(protocol, "^[!#$%&'*+.^_`|~a-zA-Z0-9-]+$")) throw new IOException("Invalid WebSocket protocol token.");
   }
   byte[] response = Encoding.ASCII.GetBytes("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: " + accept + "\r\n" + (protocol == null ? "" : "Sec-WebSocket-Protocol: " + protocol + "\r\n") + "\r\n");
   await Write(stream, response, 0, response.Length, stop).ConfigureAwait(false);
   return CreateWebSocket(stream, protocol);
  }
  static WebSocket CreateWebSocket(Stream stream, string protocol) {
   System.Reflection.MethodInfo factory = typeof(WebSocket).GetMethod("CreateFromStream", new Type[] { typeof(Stream), typeof(bool), typeof(string), typeof(TimeSpan) });
   if (factory == null) return new ManagedSocket(stream, protocol);
   return (WebSocket)factory.Invoke(null, new object[] { stream, true, protocol, TimeSpan.FromSeconds(30) });
  }
  sealed class Message { public byte[] Bytes; public WebSocketMessageType Type; }
  static async Task<Message> ReceiveWs(WebSocket ws, CancellationToken stop) {
   using (CancellationTokenSource timeout = CancellationTokenSource.CreateLinkedTokenSource(stop)) {
    timeout.CancelAfter(300000); byte[] chunk = new byte[65536]; MemoryStream message = new MemoryStream(); WebSocketMessageType? kind = null;
    while (true) {
     WebSocketReceiveResult result = await ws.ReceiveAsync(new ArraySegment<byte>(chunk), timeout.Token).ConfigureAwait(false);
     if (result.MessageType == WebSocketMessageType.Close) return null;
     if (kind.HasValue && kind.Value != result.MessageType) throw new IOException("Mixed WebSocket fragments."); kind = result.MessageType;
     if (message.Length + result.Count > MaxMessage) throw new IOException("WebSocket message exceeds 2 MiB.");
     message.Write(chunk, 0, result.Count);
     if (result.EndOfMessage) { byte[] bytes = message.ToArray(); if (result.MessageType == WebSocketMessageType.Text) new UTF8Encoding(false, true).GetString(bytes); return new Message { Bytes = bytes, Type = result.MessageType }; }
    }
   }
  }
  static async Task SendWs(WebSocket ws, byte[] bytes, WebSocketMessageType type, CancellationToken stop) { using (CancellationTokenSource timeout = CancellationTokenSource.CreateLinkedTokenSource(stop)) { timeout.CancelAfter(60000); await ws.SendAsync(new ArraySegment<byte>(bytes), type, true, timeout.Token).ConfigureAwait(false); } }
  sealed class Relay {
   readonly WebSocket ws; readonly bool version2; readonly CancellationTokenSource cancel; readonly SemaphoreSlim sender = new SemaphoreSlim(1, 1);
   readonly ConcurrentDictionary<uint, Tunnel> streams = new ConcurrentDictionary<uint, Tunnel>();
   public Relay(WebSocket socket, CancellationToken stop, bool useVersion2) { ws = socket; version2 = useVersion2; cancel = CancellationTokenSource.CreateLinkedTokenSource(stop); }
   public async Task Run() {
    try {
     if (version2) await Send(5, 0, new byte[] { 2, 0 }).ConfigureAwait(false); await Send(3, 0, Window()).ConfigureAwait(false);
     while (ws.State == WebSocketState.Open) {
      Message message = await ReceiveWs(ws, cancel.Token).ConfigureAwait(false); if (message == null) break;
      byte[] p = message.Bytes; if (message.Type != WebSocketMessageType.Binary || p.Length < 5) throw new IOException("Invalid Wisp packet.");
      byte type = p[0]; uint id = Read32(p, 1); Tunnel tunnel;
      if (type == 5) continue;
      if (type == 1) {
       if (p.Length < 9 || id == 0 || streams.ContainsKey(id)) throw new IOException("Invalid CONNECT.");
       if (streams.Count >= 64) { await Send(4, id, new byte[] { 0x49 }).ConfigureAwait(false); continue; }
       if (p[5] != 1) { await Send(4, id, new byte[] { 0x48 }).ConfigureAwait(false); continue; }
       int port = p[6] | (p[7] << 8); string host = new UTF8Encoding(false, true).GetString(p, 8, p.Length - 8);
       tunnel = new Tunnel(this, id); if (!streams.TryAdd(id, tunnel)) throw new IOException("Duplicate stream.");
       byte connectError = 0;
       try { await tunnel.Connect(host, port).ConfigureAwait(false); Interlocked.Increment(ref totalStreams); Tunnel reader = tunnel; Server.Run(delegate { return reader.Read(); }); }
       catch (UnauthorizedAccessException) { connectError = 0x48; }
       catch { connectError = 0x03; }
       if (connectError != 0) await Close(id, connectError).ConfigureAwait(false);
      } else if (type == 2) {
       if (streams.TryGetValue(id, out tunnel)) { bool failed = false; try { await tunnel.Write(p, 5, p.Length - 5).ConfigureAwait(false); } catch { failed = true; } if (failed) await Close(id, 0x03).ConfigureAwait(false); }
      } else if (type == 4) { if (streams.TryRemove(id, out tunnel)) tunnel.Dispose(); }
      else if (type != 3) throw new IOException("Unsupported Wisp packet.");
     }
    } finally { cancel.Cancel(); foreach (Tunnel tunnel in streams.Values) tunnel.Dispose(); streams.Clear(); }
   }
   static uint Read32(byte[] p, int i) { return (uint)(p[i] | p[i+1] << 8 | p[i+2] << 16 | p[i+3] << 24); }
   static byte[] Window() { return new byte[] { 128, 0, 0, 0 }; }
   public async Task Send(byte type, uint id, byte[] payload) {
    byte[] packet = new byte[5 + payload.Length]; packet[0] = type;
    packet[1] = (byte)id; packet[2] = (byte)(id >> 8); packet[3] = (byte)(id >> 16); packet[4] = (byte)(id >> 24); Buffer.BlockCopy(payload, 0, packet, 5, payload.Length);
    await sender.WaitAsync(cancel.Token).ConfigureAwait(false);
    try { await SendWs(ws, packet, WebSocketMessageType.Binary, cancel.Token).ConfigureAwait(false); } finally { sender.Release(); }
   }
   public async Task Close(uint id, byte reason) { Tunnel tunnel; if (!streams.TryRemove(id, out tunnel)) return; tunnel.Dispose(); if (!cancel.IsCancellationRequested) await Send(4, id, new byte[] { reason }).ConfigureAwait(false); }
   sealed class Tunnel : IDisposable {
    readonly Relay relay; readonly uint id; TcpClient client; NetworkStream stream; int count;
    public Tunnel(Relay owner, uint streamId) { relay = owner; id = streamId; }
    public async Task Connect(string host, int port) {
     bool owned = host == "127.0.0.1" && port == 43161;
     if (!owned && port != 443) throw new UnauthorizedAccessException();
     if (host.Length == 0 || host.Length > 253 || host != host.Trim() || host.IndexOf('%') >= 0) throw new UnauthorizedAccessException();
     IPAddress address;
     if (owned) address = IPAddress.Loopback;
     else {
      IPAddress literal;
      if (IPAddress.TryParse(host, out literal)) { if (!Public(literal)) throw new UnauthorizedAccessException(); address = literal; }
      else {
       if (!Regex.IsMatch(host, "^[a-zA-Z0-9.-]+$")) throw new UnauthorizedAccessException();
       Task<IPAddress[]> lookup = Dns.GetHostAddressesAsync(host);
       if (await Task.WhenAny(lookup, Task.Delay(10000, relay.cancel.Token)).ConfigureAwait(false) != lookup) throw new IOException("DNS timeout.");
       IPAddress[] addresses = await lookup.ConfigureAwait(false); address = null;
       // Reject mixed public/private answers; connect directly to the checked IP.
       foreach (IPAddress candidate in addresses) { if (!Public(candidate)) throw new UnauthorizedAccessException(); if (address == null || candidate.AddressFamily == AddressFamily.InterNetwork) address = candidate; }
       if (address == null) throw new IOException("No DNS answers.");
      }
     }
     client = new TcpClient(address.AddressFamily); client.NoDelay = true;
     Task connecting = client.ConnectAsync(address, port);
     if (await Task.WhenAny(connecting, Task.Delay(15000, relay.cancel.Token)).ConfigureAwait(false) != connecting) { client.Close(); throw new IOException("Connect timeout."); }
     await connecting.ConfigureAwait(false); stream = client.GetStream();
    }
    public async Task Write(byte[] bytes, int offset, int length) { await Server.Write(stream, bytes, offset, length, relay.cancel.Token).ConfigureAwait(false); Interlocked.Add(ref sent, length); if (++count % 64 == 0) await relay.Send(3, id, Window()).ConfigureAwait(false); }
    public async Task Read() {
     byte reason = 2;
     try {
      byte[] buffer = new byte[65536];
      while (!relay.cancel.IsCancellationRequested) {
       int n;
       using (CancellationTokenSource timeout = CancellationTokenSource.CreateLinkedTokenSource(relay.cancel.Token)) { timeout.CancelAfter(120000); using (timeout.Token.Register(delegate { client.Close(); })) n = await stream.ReadAsync(buffer, 0, buffer.Length, timeout.Token).ConfigureAwait(false); }
       if (n == 0) break;
       Interlocked.Add(ref received, n); byte[] payload = new byte[n]; Buffer.BlockCopy(buffer, 0, payload, 0, n); await relay.Send(2, id, payload).ConfigureAwait(false);
      }
     } catch { reason = 3; }
     await relay.Close(id, reason).ConfigureAwait(false);
    }
    public void Dispose() { if (client != null) client.Close(); }
   }
  }
  static bool Public(IPAddress ip) {
   if (ip.IsIPv4MappedToIPv6) ip = ip.MapToIPv4();
   byte[] b = ip.GetAddressBytes();
   if (b.Length == 4) {
    if (b[0] == 0 || b[0] == 10 || b[0] == 127 || b[0] >= 224 || (b[0] == 100 && b[1] >= 64 && b[1] <= 127) || (b[0] == 169 && b[1] == 254) || (b[0] == 172 && b[1] >= 16 && b[1] <= 31) || (b[0] == 192 && b[1] == 168) || (b[0] == 192 && b[1] == 0) || (b[0] == 192 && b[1] == 2) || (b[0] == 192 && b[1] == 88 && b[2] == 99) || (b[0] == 198 && (b[1] == 18 || b[1] == 19)) || (b[0] == 198 && b[1] == 51 && b[2] == 100) || (b[0] == 203 && b[1] == 0 && b[2] == 113)) return false;
    return true;
   }
   // Only global unicast IPv6. Exclude IETF special-use, documentation,
   // Teredo and 6to4 ranges, including private-address transition tunnels.
   if (b.Length != 16 || (b[0] & 0xe0) != 0x20) return false;
   if (b[0] == 0x20 && b[1] == 0x01 && b[2] <= 1) return false;
   if (b[0] == 0x20 && b[1] == 0x01 && b[2] == 0x0d && b[3] == 0xb8) return false;
   if (b[0] == 0x20 && b[1] == 0x02) return false;
   if (b[0] == 0x3f && b[1] == 0xff && (b[2] & 0xf0) == 0) return false;
   return true;
  }
  static string StatusJson() {
   List<string> hosts = new List<string>();
   try { string manifest = File.ReadAllText(Path.Combine(root, "navigation-hosts.json")); Match array = Regex.Match(manifest, "\\\"hosts\\\"\\s*:\\s*\\[([^\\]]*)\\]"); foreach (Match m in Regex.Matches(array.Groups[1].Value, "\\\"([a-zA-Z0-9.-]+)\\\"")) hosts.Add(Json(m.Groups[1].Value)); } catch { }
   return "{\"service\":\"limerence-local-helper\",\"version\":2,\"relay\":\"ws://127.0.0.1:43160/wisp/\",\"relayOwned\":true,\"approvedHosts\":[" + String.Join(",", hosts.ToArray()) + "],\"publicHttpsResources\":true}";
  }
  // Windows PowerShell's .NET Framework lacks the public stream WebSocket
  // factory. This small server-side RFC6455 transport provides the same public
  // WebSocket interface without native code, HttpListener or another program.
  sealed class ManagedSocket : WebSocket {
   readonly Stream stream; readonly string protocol; readonly SemaphoreSlim output = new SemaphoreSlim(1, 1);
   volatile WebSocketState state = WebSocketState.Open;
   WebSocketCloseStatus? closeStatus; string closeDescription;
   byte[] pending; int pendingOffset; bool pendingFinal; WebSocketMessageType pendingKind;
   int fragmentedOpcode;
   public ManagedSocket(Stream underlying, string subprotocol) { stream = underlying; protocol = subprotocol; }
   public override WebSocketCloseStatus? CloseStatus { get { return closeStatus; } }
   public override string CloseStatusDescription { get { return closeDescription; } }
   public override WebSocketState State { get { return state; } }
   public override string SubProtocol { get { return protocol; } }
   public override void Abort() { state = WebSocketState.Aborted; stream.Dispose(); }
   public override void Dispose() { state = WebSocketState.Closed; stream.Dispose(); }
   async Task Exact(byte[] bytes, int count, CancellationToken cancellation) {
    int offset = 0;
    using (cancellation.Register(delegate { stream.Dispose(); })) {
     while (offset < count) { int n = await stream.ReadAsync(bytes, offset, count - offset, cancellation).ConfigureAwait(false); if (n == 0) throw new IOException("WebSocket disconnected."); offset += n; }
    }
   }
   public override async Task<WebSocketReceiveResult> ReceiveAsync(ArraySegment<byte> buffer, CancellationToken cancellationToken) {
    if (buffer.Array == null || buffer.Count == 0) throw new ArgumentException("Receive buffer required.");
    while (pending == null) {
     byte[] header = new byte[2]; await Exact(header, 2, cancellationToken).ConfigureAwait(false);
     bool final = (header[0] & 128) != 0; int opcode = header[0] & 15;
     if ((header[0] & 112) != 0 || (header[1] & 128) == 0) throw new IOException("Invalid or unmasked client WebSocket frame.");
     ulong length = (ulong)(header[1] & 127);
     if (length == 126) { byte[] extended = new byte[2]; await Exact(extended, 2, cancellationToken).ConfigureAwait(false); length = ((ulong)extended[0] << 8) | extended[1]; if (length < 126) throw new IOException("Noncanonical WebSocket length."); }
     else if (length == 127) { byte[] extended = new byte[8]; await Exact(extended, 8, cancellationToken).ConfigureAwait(false); if ((extended[0] & 128) != 0) throw new IOException("Invalid WebSocket length."); length = 0; foreach (byte b in extended) length = (length << 8) | b; if (length < 65536) throw new IOException("Noncanonical WebSocket length."); }
     bool control = opcode >= 8;
     if (length > MaxMessage || (control && (!final || length > 125))) throw new IOException("WebSocket frame limit exceeded.");
     if (opcode != 0 && opcode != 1 && opcode != 2 && opcode != 8 && opcode != 9 && opcode != 10) throw new IOException("Reserved WebSocket opcode.");
     byte[] mask = new byte[4]; await Exact(mask, 4, cancellationToken).ConfigureAwait(false);
     byte[] payload = new byte[(int)length]; await Exact(payload, payload.Length, cancellationToken).ConfigureAwait(false);
     for (int i = 0; i < payload.Length; i++) payload[i] ^= mask[i & 3];
     if (opcode == 9) { await Frame(10, payload, true, cancellationToken).ConfigureAwait(false); continue; }
     if (opcode == 10) continue;
     if (opcode == 8) {
      if (payload.Length == 1) throw new IOException("Invalid WebSocket close.");
      if (payload.Length >= 2) {
       int code = payload[0] * 256 + payload[1];
       if (code < 1000 || code >= 5000 || code == 1004 || code == 1005 || code == 1006 || code == 1015 || (code >= 1016 && code < 3000)) throw new IOException("Invalid WebSocket close status.");
       closeStatus = (WebSocketCloseStatus)code; closeDescription = new UTF8Encoding(false, true).GetString(payload, 2, payload.Length - 2);
      }
      state = WebSocketState.CloseReceived;
      await Frame(8, payload, true, cancellationToken).ConfigureAwait(false);
      state = WebSocketState.Closed;
      return new WebSocketReceiveResult(0, WebSocketMessageType.Close, true, closeStatus, closeDescription);
     }
     int kind = opcode;
     if (opcode == 0) { if (fragmentedOpcode == 0) throw new IOException("Unexpected continuation."); kind = fragmentedOpcode; if (final) fragmentedOpcode = 0; }
     else { if (fragmentedOpcode != 0) throw new IOException("Interrupted fragmented message."); if (!final) fragmentedOpcode = opcode; }
     pending = payload; pendingOffset = 0; pendingFinal = final; pendingKind = kind == 1 ? WebSocketMessageType.Text : WebSocketMessageType.Binary;
    }
    int count = Math.Min(buffer.Count, pending.Length - pendingOffset); Buffer.BlockCopy(pending, pendingOffset, buffer.Array, buffer.Offset, count); pendingOffset += count;
    bool end = pendingOffset == pending.Length && pendingFinal; WebSocketMessageType type = pendingKind;
    if (pendingOffset == pending.Length) pending = null;
    return new WebSocketReceiveResult(count, type, end);
   }
   async Task Frame(int opcode, byte[] payload, bool final, CancellationToken cancellationToken) {
    await output.WaitAsync(cancellationToken).ConfigureAwait(false);
    try {
     MemoryStream frame = new MemoryStream(); frame.WriteByte((byte)(opcode | (final ? 128 : 0)));
     if (payload.Length < 126) frame.WriteByte((byte)payload.Length);
     else if (payload.Length <= 65535) { frame.WriteByte(126); frame.WriteByte((byte)(payload.Length >> 8)); frame.WriteByte((byte)payload.Length); }
     else { frame.WriteByte(127); for (int i = 7; i >= 0; i--) frame.WriteByte((byte)((ulong)payload.Length >> (8 * i))); }
     frame.Write(payload, 0, payload.Length); byte[] bytes = frame.ToArray(); await Server.Write(stream, bytes, 0, bytes.Length, cancellationToken).ConfigureAwait(false);
    } finally { output.Release(); }
   }
   public override Task SendAsync(ArraySegment<byte> buffer, WebSocketMessageType messageType, bool endOfMessage, CancellationToken cancellationToken) {
    if (state != WebSocketState.Open) throw new IOException("WebSocket is closed.");
    if (messageType != WebSocketMessageType.Binary && messageType != WebSocketMessageType.Text) throw new ArgumentException("Use CloseOutputAsync for close messages.");
    if (buffer.Count > MaxMessage) throw new IOException("WebSocket message limit exceeded.");
    byte[] payload = new byte[buffer.Count]; Buffer.BlockCopy(buffer.Array, buffer.Offset, payload, 0, buffer.Count);
    return Frame(messageType == WebSocketMessageType.Text ? 1 : 2, payload, endOfMessage, cancellationToken);
   }
   public override async Task CloseOutputAsync(WebSocketCloseStatus status, string description, CancellationToken cancellationToken) {
    byte[] text = Encoding.UTF8.GetBytes(description ?? ""); if (text.Length > 123) throw new ArgumentException("Close description too long.");
    byte[] payload = new byte[text.Length + 2]; payload[0] = (byte)((int)status >> 8); payload[1] = (byte)status; Buffer.BlockCopy(text, 0, payload, 2, text.Length);
    await Frame(8, payload, true, cancellationToken).ConfigureAwait(false); state = WebSocketState.CloseSent;
   }
   public override Task CloseAsync(WebSocketCloseStatus status, string description, CancellationToken cancellationToken) { return CloseOutputAsync(status, description, cancellationToken); }
  }
  static string Json(string value) { StringBuilder output = new StringBuilder("\""); foreach (char c in value) { if (c == '\\' || c == '"') output.Append('\\').Append(c); else if (c < 32) output.Append("\\u").Append(((int)c).ToString("x4")); else output.Append(c); } return output.Append('"').ToString(); }
 }
}
