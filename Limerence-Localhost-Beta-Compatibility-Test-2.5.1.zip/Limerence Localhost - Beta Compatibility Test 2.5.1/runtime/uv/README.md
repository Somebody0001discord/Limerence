# Ultraviolet support source

The adapter and dedicated service worker are implemented here. Vendor files must be fetched and verified using `fetch-vendor.py` before this module can run. **The presence of these source files does not mean the engine is installed or tested.**

Expected pinned files:

- `vendor/ultraviolet/dist/{uv.bundle,uv.client,uv.handler,uv.sw}.js` from official `v3.2.10-headers`.
- `vendor/baremux/dist/{index.mjs,worker.js}` from BareMux 2.1.9.
- Their complete shipped `LICENSE` files, source archives, release source maps, and verified `vendor-manifest.json`.

Ultraviolet's npm metadata says MIT while the actual release ships GNU AGPL v3. Preserve the actual shipped license and corresponding source; do not replace it with the package metadata label. BareMux's shipped license is MIT, despite the absent npm license field. The existing Epoxy/libcurl AGPL notices remain required.

Call `createUVFrame({element,targetUrl,session,transport,identity,onDocument,onReady,onError,signal})` from `uv-adapter.js`, passing the already initialized and identity-decorated **new** ProxyTransport. The bridge uses official BareMux `setRemoteTransport` and converts request/response raw-header formats. No second/legacy transport implementation is needed. `identity` is the normalized custom snapshot or null for mirror mode. The dedicated worker `/uv/sw.js` controls only `/uv/service/`; the existing Scramjet worker can retain `/`.

The returned `{cleanup,frame,connection}` does not establish game readiness. `onDocument` describes only an executed document bootstrap. `onReady` exists only for the owned exact test target. For other games leave readiness unobservable and ask the user to confirm rather than replacing a potentially working frame on a timer. Parent-side source/origin/session checks remain required.

For a complete teardown, remove the helper iframe and its browsing context. That boundary also closes the transport runtime; replacing an engine dropdown or deleting the game iframe alone is insufficient. The adapter releases its own timer/listener/SW session and BareMux port, but does not claim to migrate existing network sessions.

Custom identity changes the document's navigator fields and target request headers. It does not change the real engine, worker Navigator, TLS implementation or all identifying surfaces. The optional local relay has a reviewed target allowlist; this UV work has only used the owned fixture in its test design and has not yet forwarded game traffic.
