/* Ultraviolet / BareMux bridge. Requires pinned vendor files from fetch-vendor.py.
   No capabilities are asserted by this module until its real imports succeed. */
const URLS={bundle:'/uv/vendor/ultraviolet/dist/uv.bundle.js',mux:'/uv/vendor/baremux/dist/index.mjs',worker:'/uv/vendor/baremux/dist/worker.js'};
let bundlePromise;
function loadBundle(){return bundlePromise??=new Promise((resolve,reject)=>{const script=document.createElement('script');script.src=URLS.bundle;script.onload=()=>globalThis.Ultraviolet?resolve():reject(new Error('Ultraviolet bundle did not expose its API.'));script.onerror=()=>reject(new Error('Ultraviolet vendor runtime is unavailable. Run the documented vendor download step.'));document.head.append(script);});}
export const rawHeaders=headers=>Array.isArray(headers)?headers.flatMap(([name,value])=>(Array.isArray(value)?value:[value]).map(v=>[name,String(v)])):Object.entries(headers||{}).flatMap(([name,value])=>(Array.isArray(value)?value:[value]).map(v=>[name,String(v)]));
export function bareHeaders(headers){const result={};for(const [key,value] of rawHeaders(headers)){const name=key.toLowerCase();if(Object.hasOwn(result,name))result[name]=[].concat(result[name],value);else result[name]=value;}return result;}
export function createHeaderBridge(transport){return{get ready(){return transport.ready;},init:()=>transport.init(),meta:()=>({}),async request(remote,method,body,headers,signal){const r=await transport.request(remote,method,body,rawHeaders(headers),signal);return{...r,headers:bareHeaders(r.headers)};},connect(remote,protocols,headers,onopen,...callbacks){return transport.connect(remote,protocols,rawHeaders(headers),protocol=>onopen(protocol),...callbacks);}};}
const send=(worker,data)=>new Promise((resolve,reject)=>{const channel=new MessageChannel(),timer=setTimeout(()=>{channel.port1.close();reject(new Error('Ultraviolet service worker configuration timed out.'));},7000);channel.port1.onmessage=event=>{clearTimeout(timer);channel.port1.close();event.data?.ok?resolve(event.data):reject(new Error(event.data?.error||'Ultraviolet configuration was rejected.'));};worker.postMessage(data,[channel.port2]);});
async function activated(registration){if(registration.active?.state==='activated')return registration.active;const worker=registration.installing||registration.waiting||registration.active;if(!worker)throw new Error('Ultraviolet service worker is unavailable.');await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(new Error('Ultraviolet service worker activation timed out.')),10000);const check=()=>{if(worker.state==='activated'){clearTimeout(timer);worker.removeEventListener('statechange',check);resolve();}else if(worker.state==='redundant'){clearTimeout(timer);worker.removeEventListener('statechange',check);reject(new Error('Ultraviolet service worker became redundant.'));}};worker.addEventListener('statechange',check);check();});return worker;}
export async function createUVFrame({element,targetUrl,session,transport,identity,onDocument=()=>{},onReady=()=>{},onError=()=>{},signal}){
 if(!/^[A-Za-z0-9_-]{6,120}$/.test(session||''))throw new Error('Invalid Ultraviolet session identifier.');
 const remote=new URL(targetUrl);if(!['http:','https:'].includes(remote.protocol))throw new Error('Ultraviolet target must be an HTTP(S) browser game.');
 await loadBundle();const {BareMuxConnection}=await import(URLS.mux);if(signal?.aborted)throw signal.reason;
 const connection=new BareMuxConnection(URLS.worker+'?session='+encodeURIComponent(session));
 await connection.setRemoteTransport(createHeaderBridge(transport),'Limerence '+session);
 const registration=await navigator.serviceWorker.register('/uv/sw.js',{scope:'/uv/service/'}),worker=await activated(registration);
 await send(worker,{type:'limerence-uv-config',session,identity:identity||null});if(signal?.aborted)throw signal.reason;
 const nonce=crypto.randomUUID(),prefix='/uv/service/'+session+'/';
 let stopped=false,readySent=false;
 const listener=event=>{if(stopped||event.source!==element.contentWindow||event.origin!==location.origin||event.data?.channel!=='limerence-uv-document'||event.data?.session!==session||event.data?.nonce!==nonce)return;onDocument({phase:'unobservable',message:'Ultraviolet document script initialized. Confirm the game starts; this signal does not establish gameplay.'});};
 addEventListener('message',listener);
 await send(worker,{type:'limerence-uv-config',session,identity:identity||null,nonce});
 const poll=setInterval(()=>{if(stopped||readySent||remote.href!=='http://127.0.0.1:43161/game')return;try{if(typeof element.contentWindow.fixtureState==='function'){readySent=true;onReady({message:'Controlled game initialized through Ultraviolet. Gameplay still requires verification.'});}}catch{}},150);
 const heartbeat=setInterval(()=>send(worker,{type:'limerence-uv-config',session,identity:identity||null,nonce}).catch(error=>{if(!stopped)onError({category:'engine',message:error.message});}),20000);
 function cleanup(){if(stopped)return;stopped=true;clearInterval(poll);clearInterval(heartbeat);removeEventListener('message',listener);signal?.removeEventListener('abort',cleanup);element.remove();send(worker,{type:'limerence-uv-stop',session}).catch(()=>{});try{connection.worker.channel.close();Promise.resolve(connection.getInnerPort()).then(port=>port.close()).catch(()=>{});}catch{}}
 signal?.addEventListener('abort',cleanup,{once:true});element.src=prefix+encodeURIComponent(remote.href);
 return{cleanup,frame:{element,go(url){element.src=prefix+encodeURIComponent(url);}},connection};
}
