import EpoxyTransport from './vendor/epoxy/dist/index.mjs';
import LibcurlTransport from './vendor/libcurl/dist/index.mjs';
const status=document.querySelector('#status'),stage=document.querySelector('#stage');
const capabilities={engines:['scramjet','ultraviolet'],transports:['epoxy','libcurl'],versions:{scramjet:'2.0.67-alpha.2',controller:'0.0.14',epoxy:'3.0.2',libcurl:'2.0.6'},relayDefault:null,controlledTarget:'http://127.0.0.1:43161/game'};
let current=null,parentOrigin=null;
const NativeWebSocket=window.WebSocket;
window.WebSocket=class extends NativeWebSocket{constructor(...args){super(...args);const owner=current;if(owner){owner.sockets.add(this);this.addEventListener('close',()=>owner.sockets.delete(this));}}};
function report(type,fields={},owner=current){if(!owner||current!==owner)return;status.textContent=String(fields.message||type).replace(/\bproxy\b/gi,w=>w[0]===w[0].toUpperCase()?'External':'external');const message={channel:'lucent-proxy',type,session:owner.session,...fields};if(parent!==window)parent.postMessage(message,parentOrigin==='null'?'*':parentOrigin||'*');window.lastReport=message;}
function cleanup(){const old=current;current=null;if(old){old.abort.abort();old.uv?.cleanup?.();for(const id of old.timers)clearInterval(id);old.frame?.element?.remove();stage.replaceChildren();for(const socket of old.sockets)try{socket.close(1000,'Limerence session stopped');}catch{};try{old.raw?.session?.close();}catch{};try{old.raw?.client?.free();}catch{}}status.textContent='Session stopped. No player frame remains.';}
const timeout=(promise,ms,label,owner)=>new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(new Error(label)),ms);owner.timers.add(timer);Promise.resolve(promise).then(resolve,reject).finally(()=>clearTimeout(timer));});
async function probeRelay(relay,owner){return timeout(new Promise((resolve,reject)=>{let ws;try{ws=new WebSocket(relay);}catch(e){reject(e);return;}ws.binaryType='arraybuffer';ws.onmessage=e=>{const bytes=new Uint8Array(e.data);ws.close();if(bytes.length>=5&&[3,5].includes(bytes[0]))resolve();else reject(new Error('The configured endpoint did not return a Wisp greeting.'));};ws.onerror=()=>reject(new Error('Cannot reach the configured Wisp relay. Check its URL and availability.'));ws.onclose=e=>{if(!e.wasClean)reject(new Error('The configured Wisp connection closed before its greeting.'));};}),6500,'Wisp greeting timed out. Check the configured relay.',owner);}
function identitySnapshot(value){if(value?.mode!=='custom')return null;const out={};for(const name of ['userAgent','platform','vendor']){out[name]=String(value[name]||'');if(/[\r\n]/.test(out[name])||out[name].length>1024)throw new Error('Identity contains an invalid value.');}if(!out.userAgent)throw new Error('Custom identity needs a user-agent.');out.appVersion=out.userAgent.replace(/^Mozilla\//,'');return out;}
function wrap(raw,identity,owner){const headers=h=>identity?h.filter(([k])=>!/^user-agent$/i.test(k)&&!/^sec-ch-ua(?:-|$)/i.test(k)).concat([['User-Agent',identity.userAgent]]):h;
 const checkUrl=(url,socket=false)=>{const own=url.hostname==='127.0.0.1'&&url.port==='43161'&&url.protocol===(socket?'ws:':'http:');if(!own&&(url.protocol!==(socket?'wss:':'https:')||(url.port&&url.port!=='443')))throw Object.assign(new Error('Only public secure website resources and the owned test fixture are supported.'),{category:'unknown'});};
 return{get ready(){return raw.ready;},init:()=>raw.init(),meta:()=>raw.meta(),request:async(remote,method,body,h,signal)=>{if(current!==owner)throw new Error('Stale session');checkUrl(remote);let response;try{response=await raw.request(remote,method,body,headers(h),signal);}catch(error){const failure=error instanceof Error?error:new Error(String(error));failure.category='transport';throw failure;}owner.requests++;owner.requestsSummary.push({url:remote.origin+remote.pathname,status:response.status});if(owner.requestsSummary.length>20)owner.requestsSummary.shift();report('progress',{phase:'loading',loaded:owner.requests,message:'Receiving game content through '+owner.transport+'…'},owner);return response;},connect:(url,protocols,h,...callbacks)=>{checkUrl(url,true);return raw.connect(url,protocols,headers(h),...callbacks);}};}
function watchGameReadiness(owner,target,element){
 if(target!=='https://wayou.github.io/t-rex-runner/')return;
 const poll=setInterval(()=>{if(current!==owner){clearInterval(poll);return;}try{const win=element.contentWindow,instance=win.Runner?.instance_;if(instance&&instance.tRex&&win.document.querySelector('canvas')){clearInterval(poll);report('ready',{evidence:'game-adapter',adapter:'wayou-dino-v1',targetUrl:target,message:'Dino initialized through the selected external connection. Click inside to start.'},owner);}}catch{}},180);owner.timers.add(poll);
}
async function launch(config){
 cleanup();const owner=current={session:config.session||crypto.randomUUID(),abort:new AbortController(),sockets:new Set(),timers:new Set(),requests:0,requestsSummary:[],transport:config.transport};
 let target;try{target=new URL(config.targetUrl);}catch{throw Object.assign(new Error('The configured website URL is invalid.'),{category:'unknown'});}
 if(target.href!==capabilities.controlledTarget&&(target.protocol!=='https:'||!capabilities.approvedHosts?.includes(target.hostname)))throw Object.assign(new Error('This initial website is not in the reviewed game catalog. Add a verified HTTPS source to the editable catalog first.'),{category:'unknown'});
 if(!capabilities.engines.includes(config.engine))throw Object.assign(new Error('The selected engine is not installed in this helper.'),{category:'engine'});
 if(config.relayEligible!==true)throw Object.assign(new Error('Relay operator eligibility must be confirmed. No external relay is configured by default.'),{category:'relay'});
 let relay;try{relay=new URL(config.relay);}catch{throw Object.assign(new Error('Enter a valid Wisp WebSocket URL.'),{category:'relay'});}
 if(!['wss:','ws:'].includes(relay.protocol)||relay.username||relay.password)throw Object.assign(new Error('Wisp URL must use ws: or wss: without embedded credentials.'),{category:'relay'});
 if(config.transport==='libcurl'&&!relay.pathname.endsWith('/'))throw Object.assign(new Error('The installed libcurl Wisp runtime requires a relay path ending with /. Enter the operator-documented path.'),{category:'transport'});
 report('progress',{message:'Checking the selected Wisp relay…'},owner);
 try{await probeRelay(relay.href,owner);}catch(e){throw Object.assign(e,{category:'relay'});}if(current!==owner)return;
 const raw=config.transport==='epoxy'?new EpoxyTransport({wisp:relay.href}):config.transport==='libcurl'?new LibcurlTransport({wisp:relay.href}):null;
 if(!raw)throw Object.assign(new Error('Requested transport is not installed.'),{category:'transport'});owner.raw=raw;
 const identity=identitySnapshot(config.identity);const transport=wrap(raw,identity,owner);
 report('progress',{message:'Initializing '+config.transport+' transport…'},owner);
 try{await timeout(raw.init(),15000,'Transport initialization timed out.',owner);}catch(e){throw Object.assign(e,{category:'transport'});}if(current!==owner)return;
 if(identity&&raw.client)raw.client.user_agent=identity.userAgent;
 // UV uses its installed HTTP runtime and BareMux bridge to the selected transport.
 if(config.engine==='ultraviolet'){
  const element=document.createElement('iframe');element.title='Limerence proxied content';element.allow='fullscreen; autoplay';stage.append(element);
  try{
   const {createUVFrame}=await import('./uv/uv-adapter.js');
   const uv=await createUVFrame({element,targetUrl:config.targetUrl,session:owner.session,transport,identity,onDocument:data=>report('document',data,owner),onReady:data=>report('ready',data,owner),onError:data=>report('error',data,owner),signal:owner.abort.signal});
   owner.frame=uv.frame;owner.uv=uv;watchGameReadiness(owner,config.targetUrl,element);
   return{frame:uv.frame,cleanup,sessionId:owner.session};
  }catch(error){throw Object.assign(error,{category:error.category||'engine'});}
 }
 const registration=await navigator.serviceWorker.register('/sw.js',{scope:'/'});await navigator.serviceWorker.ready;
 const worker=registration.active||registration.waiting||registration.installing;
 const controller=new $scramjetController.Controller({serviceworker:worker,transport,config:{prefix:'/~/sj/',scramjetPath:'/vendor/scramjet/dist/scramjet.js',injectPath:'/vendor/controller/dist/controller.inject.js',wasmPath:'/vendor/scramjet/dist/scramjet.wasm'}});owner.controller=controller;
 try{await timeout(controller.wait(),15000,'External controller did not become ready.',owner);}catch(e){throw Object.assign(e,{category:'engine'});}if(current!==owner)return;
 const element=document.createElement('iframe');element.title='Limerence proxied content';element.allow='fullscreen; autoplay';stage.append(element);const frame=controller.createFrame(element);owner.frame=frame;
 $scramjet.Tap.tap(frame.hooks.error.request,({error,rawrequest})=>{if(['document','iframe'].includes(rawrequest.destination))report('error',{category:error?.category||'unknown',message:error?.message||String(error)},owner);});
 if(identity)$scramjet.Tap.tap(frame.hooks.init.pre,({client,window:win})=>{for(const name of ['userAgent','appVersion','platform','vendor']){try{client.Trap('Navigator.prototype.'+name,{get:()=>identity[name]});}catch(e){report('identity-warning',{message:'Document identity override failed for '+name+': '+e.message},owner);}}try{if('userAgentData' in win.navigator)client.Trap('Navigator.prototype.userAgentData',{get:()=>undefined});}catch(e){report('identity-warning',{message:e.message},owner);}});
 $scramjet.Tap.tap(frame.hooks.init.post,({isTopLevel})=>{if(isTopLevel)report('document',{phase:'unobservable',message:'Rewritten document initialized. Confirm the game starts; document initialization alone does not prove gameplay.'},owner);});
 report('progress',{phase:'loading',loaded:0,message:'Loading the game through '+config.transport+'…'},owner);
 frame.go(config.targetUrl);watchGameReadiness(owner,config.targetUrl,element);
 if(config.targetUrl===capabilities.controlledTarget){const poll=setInterval(()=>{if(current!==owner)return;try{if(typeof element.contentWindow.fixtureState==='function'){clearInterval(poll);report('ready',{message:'Controlled game initialized through '+owner.transport+'. Keyboard and audio still need gameplay verification.'},owner);}}catch{}},150);owner.timers.add(poll);}
 return{frame,cleanup,sessionId:owner.session};
}

window.addEventListener('message',event=>{if(event.source!==parent||!['null',location.origin].includes(event.origin))return;const data=event.data;if(!data||data.channel!=='lucent-proxy'||typeof data.session!=='string'||data.session.length>120)return;if(data.type==='stop'&&data.session===current?.session)cleanup();if(data.type==='launch'){parentOrigin=event.origin;launch(data).catch(e=>{if(current?.session===data.session)report('error',{category:e.category||'engine',message:e.message});});}});
window.addEventListener('pagehide',cleanup);document.querySelector('#stop').onclick=cleanup;
// Only the actual unified local helper advertises its included relay. A static
// file server alone never becomes a working Wisp relay by changing a label.
try{const response=await fetch('/helper-status.json',{cache:'no-store'});if(response.ok){const info=await response.json();if(info.service==='limerence-local-helper'&&info.relayOwned===true&&info.relay==='ws://127.0.0.1:43160/wisp/'){capabilities.relayDefault=info.relay;capabilities.relayOwned=true;capabilities.approvedHosts=info.approvedHosts;}}}catch{}
window.LucentProxy={launch,cleanup,capabilities,get state(){return current&&{requests:current.requests,requestsSummary:current.requestsSummary,sockets:current.sockets.size,transport:current.transport,session:current.session};}};
if(parent!==window)parent.postMessage({channel:'lucent-proxy',type:'hello',capabilities},'*');






